<?php
date_default_timezone_set('Asia/Jakarta');
error_reporting(true);
set_time_limit(0);
ini_set('memory_limit', '-1');
ini_set('output_buffering',0); 
ini_set('request_order', 'GP');
ini_set('variables_order','EGPCS');
ini_set('max_execution_time','-1');

require __DIR__.'/class.php';
require __DIR__.'/config.php';
$files = file_get_contents(__DIR__.'/accounts_list.txt');
$files = str_replace("\r\n","\n", $files);
$file = explode("\n", $files);
foreach($file as $data){
    $login =explode(':', $data);
    $mail = $login[0];
    $pass = $login[1];
    if(isset($mail,$pass) && $mail !='' || $pass!=''){
        $new = new earnyourcrypto($mail, $pass);
        $new->getData('https://earnyourcrypto.com/');
        if($new->login()){
            if($new->setWallet($config['wallet'],$config['tag'])){
                $info = $new->getInfo();
                if(isset($info) && $info !=''){
                    echo "Your Wallet\t:\t".$info['wallet']."\n";
                    unlink("cookie");
                }
            }
         }
    }
}