<?php namespace PhpImap;

/**
 * @see https://github.com/barbushin/php-imap
 * @author Barbushin Sergey http://linkedin.com/in/barbushin
 */
class IncomingMailAttachment {

	public $id;
	public $contentId;
	public $name;
	public $filePath;
	public $disposition;
}
