<?php
error_reporting(true);
require __DIR__.'/autoload.php';
use CloudflareBypass\RequestMethod\CFCurl;

class earnyourcrypto
{
protected $username;
protected $email;
protected $password;

public function __construct($email, $password, $username=null){
    $this->email    = $email;
    $this->password = $password;
    $this->username = $username;
}
    
public function signup(){
    $field = array('create_account'=>'Create+Account','email'=>$this->email,'password'=>$this->password,'signup-terms'  => 'on','username' => $this->username);
    $signup = $this->postData('https://earnyourcrypto.com/', http_build_query($field));
    return $signup['info'];
}
    
public function login(){
	$data = array('login'=>'Login','email'=> $this->email,'password'=> $this->password);
    $login = $this->postData('https://earnyourcrypto.com/', http_build_query($data));
    return $login['info'];
}
    
public function logOut(){
    return $this->getData('https://earnyourcrypto.com/ok-logout');
}

public function setWallet($wallet, $tag){
    if($this->getData('https://earnyourcrypto.com/settings')){
        $form = array('update_xrp_wallet'=>'Update+XRP+Wallet','xrp_deposit_address'=>$wallet,'xrp_deposit_tag'=> $tag);
        $postwallet = $this->postData('https://earnyourcrypto.com/settings/', http_build_query($form));
    }
    return $postwallet['info'];
}
    
public function reqPayout(){
    if($this->getData('https://earnyourcrypto.com/exchange')){
        $info = $this->getInfo();
        $req = array('xrp_deposit_address' => $info['wallet'], 'xrp_deposit_tag' => $info['tag'], 'eyc_credits_exchange' => $info['balance'], 'request_payout' => 'Request+payout');
        $payout = $this->postData('https://earnyourcrypto.com/exchange/', http_build_query($req));
    }
    return $payout['info'];
}
    

public function getUrl(){
    $url = $this->getData('https://earnyourcrypto.com/visit-friends');
	$r = explode("var diezeUrl = '", $url['exec']);
	$g = explode("';", $r[1]);
    if($g[0] !=''){
        $link= $g[0]."&source=captcha_check";
        $this->saveAds($link);
    }else{
        $file = file('ads_url.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $link= $file[rand(0, count($file)-1)];
   }
    return $link;
    
}
    
public function saveAds($url){
    $file = fopen('ads_url.txt', 'a');
            fwrite($file,$url."\n");
            fclose($file);
    return $file;
}
    
 
public function getInfo(){
    $home = $this->getData('https://earnyourcrypto.com/settings');
    // INFO USERNAME
    $na = explode("<div class=\"border-b pb-15 mb-15\">\n", $home['exec']);
    $me = explode('<br>', $na[1]);
    // INFO BALANCE
    $ba = explode('<a class="font-size-lg" href="https://earnyourcrypto.com/exchange">$', $home['exec']);
    $la = explode('</a>', $ba[1]);
    // INFO WALLET
    $wa = explode('name="xrp_deposit_address" value="', $home['exec']);
    $let =explode('">', $wa[1]);
    // INFO TAG
    $ta = explode('name="xrp_deposit_tag" placeholder="" value="', $home['exec']);
    $g = explode('">', $ta[1]);
    //INFO EMAIL
    $em = explode('name="crypto-settings-email" placeholder="Enter your email.." value="', $home['exec']);
    $mail = explode('" disabled="yes">', $em[1]);
    $info['wallet']     = $let[0];
    $info['tag']        = $g[0];
    $info['balance']    = $la[0];
    $info['username']   = $me[0];
    $info['email']      = $mail[0];
    return $info;
}
    
public function userAgent(){
    $file = file('user-agent.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    return $file[rand(0, count($file)-1)];
}
    
public function referer(){
    $file = file('ads_url.txt', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    return $file[rand(0, count($file)-1)];
}
    
public function getData($url){
 $curl = new CFCurl(array('cache' => true, 'max_retries' => 1));
 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, $url);
 curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
 curl_setopt($ch, CURLOPT_MAXREDIRS,5);
 curl_setopt($ch, CURLOPT_REFERER, $this->referer);
 curl_setopt($ch, CURLOPT_HEADER,true);
 curl_setopt($ch, CURLOPT_USERAGENT, $this->userAgent);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 curl_setopt($ch, CURLOPT_COOKIE, "PHPSESSID=aeceb2305d7b3b0f0a55784d183c2366");
 $get['exec'] = $curl->exec($ch);
 $get['info'] = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
 return $get;
}

public function postData($url, $post){
 $curl = new CFCurl(array('cache' => true, 'max_retries' => 1));
 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, $url);
 curl_setopt($ch, CURLOPT_POST, true);
 curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
 curl_setopt($ch, CURLOPT_HEADER,true);
 curl_setopt($ch, CURLOPT_HTTPHEADER,"Content-Type: application/x-www-form-urlencoded");
 curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
 curl_setopt($ch, CURLOPT_MAXREDIRS,5);
 curl_setopt($ch, CURLOPT_REFERER, $this->referer);
 curl_setopt($ch, CURLOPT_USERAGENT, $this->userAgent);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie");
 curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie");
 $get['exec'] = $curl->exec($ch);
 $get['info'] = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
 return $get;
}
}

?>