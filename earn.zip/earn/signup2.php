<?php
date_default_timezone_set('Asia/Jakarta');
error_reporting(true);
set_time_limit(0);
ini_set('memory_limit', '-1');
ini_set('output_buffering',0); 
ini_set('request_order', 'GP');
ini_set('variables_order','EGPCS');
ini_set('max_execution_time','-1');
require __DIR__.'/class.php';
include __DIR__.'/config.php';

echo "\nSignup To https://early.coinberry.com/?kid=QHVMM\n";
echo "\nTotal User Signup\t\t=\t";
$us = trim(fgets(STDIN));
for($i=1;$i<=$us; $i++){
    $num = rand(100, 999);
    $word = getWorld();
    $name = $word;
    $mail = $name.'@'.$config['mailhost'][rand(0,count($config['mailhost'])-rand(0,count($config['mailhost'])))];
    $pass = $name.$num;
    if(isset($name,$mail,$pass) && $name != '' || $mail !='' || $pass !=''){
        $new = new earnyourcrypto($mail, $pass, $name);
        $new->getData('https://early.coinberry.com/?kid=QHVMM/');
        if($signup = $new->signup()){
            $new->getData($signup);
            saveMail($mail.':'.$pass."\n");
            echo "Email {$mail} Success Signup\n";
            unlink("cookie");
        }
    }else{
        die("\nSignup Failed or something was wrong!!!\n");
    }
    if($i >=$us){
        echo "All Email and Password was save in accounts_list.txt\n";
        
    }
}

function getWorld() {
    $c  = 'bcdfghjklmnprstwy'; //consonants except hard to speak ones
    $v  = 'aiueo';              //vowels
    $a  = $c.$v;                //both
    $pw = '';
    for($j=0;$j < 3; $j++){
        $pw .= $c[rand(0, strlen($c)-1)];
        $pw .= $v[rand(0, strlen($v)-1)];
        $pw .= $a[rand(0, strlen($a)-1)];
    }
    return $pw;
}

function saveMail($email){
    $mail = fopen('accounts_list.txt','a');
            fwrite($mail, $email);
            fclose($mail);
    return $mail;
}
?>