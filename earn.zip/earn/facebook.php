<?php

class facebook
{
protected $email;
protected $password;
protected $appid;
public function __construct($appid,$email, $password){
	$this->email = $email;
	$this->password = $password;
    $this->appid =$appid;
}

private function fbGet($url, $post=null){
 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, $url);
 if($post!=null){
  curl_setopt($ch, CURLOPT_POST, true);
  curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
 }
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
 curl_setopt($ch, CURLOPT_HEADER, true);
 curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; rv:28.0) Gecko/20100101 Firefox/28.0");
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
 curl_setopt($ch, CURLOPT_SESSIONCOOKIE, true);
 curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie_fb");
 curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie_fb");
 $get['exec'] = curl_exec($ch);
 $get['info'] = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
 curl_close($ch);
 return $get;
}

public function userLogin(){
	$data = array("email" => $this->email, "pass" => $this->password, "login" => "Masuk");
	$login = $this->fbGet("https://www.facebook.com/login.php", http_build_query($data));
	return $login;
}

public function getToken(){
     $ge = $this->fbGet("https://www.facebook.com/v2.2/dialog/oauth?response_type=token&display=iframe&client_id=".$this->appid."&redirect_uri=https%3A%2F%2Fwww.facebook.com%2Fconnect%2Flogin_success.html&scope=email%2Cpublish_actions%2Cpublish_stream%2Cuser_likes%2Cuser_status%2Cuser_about_me%2Cuser_location%2Cuser_tagged_places%2Cuser_birthday%2Cuser_photos%2Cuser_videos%2Cuser_education_history%2Cuser_posts%2Cuser_website%2Cuser_friends%2Cuser_relationship_details%2Cuser_work_history%2Cuser_games_activity%2Cuser_relationships%2Cuser_hometown%2Cuser_religion_politics%2Cuser_actions.books%2Cuser_actions.music%2Cuser_actions.video%2Cuser_actions.fitness%2Cuser_actions.news%2Cfriends_about_me%2Cfriends_actions.books%2Cfriends_actions.music%2Cfriends_actions.news%2Cfriends_actions.video%2Cfriends_activities%2Cfriends_birthday%2Cfriends_checkins%2Cfriends_education_history%2Cfriends_events%2Cfriends_games_activity%2Cfriends_groups%2Cfriends_hometown%2Cfriends_interests%2Cfriends_likes%2Cfriends_location%2Cfriends_notes%2Cfriends_photo_video_tags%2Cfriends_photos%2Cfriends_questions%2Cfriends_relationship_details%2Cfriends_relationships%2Cfriends_religion_politics%2Cfriends_status%2Cfriends_subscriptions%2Cfriends_videos%2Cfriends_website%2Cfriends_work_history%2Cads_management%2Cpages_messaging%2Cread_page_mailboxes%2Cads_read%2Cpages_messaging_phone_number%2Crsvp_event%2Cmanage_pages%2Cpages_messaging_subscriptions%2Cuser_events%2Cpages_manage_cta%2Cpages_show_list%2Cuser_managed_groups%2Cpages_manage_instant_articles%2Cpublish_pages%2Cinstagram_basic%2Cinstagram_manage_insights%2Cread_custom_friendlists%2Cinstagram_manage_comments%2Cread_audience_network_insights%2Cread_insights%2Cread_stream&status=granted&method=GET");
     $tok = preg_match("/access_token=(.*?)&expires_in/i", $ge, $m);
     if(!is_null($m[1])){
         $m[1];
     }
  return $m[1];
}

public function post($token,$message){
    $post = $this->fbGet("https://graph.facebook.com/v2.2/me/feed", http_build_query(array("access_token" => $token, "message" => $message, "method=POST&fields=id")));
    if(isset($post['info']) && $post['info'] != ''){
        unlink("cookie_fb");
    }
  return $post;
}
}
?>