<?php
date_default_timezone_set('Asia/Jakarta');
error_reporting(true);
set_time_limit(0);
ini_set('memory_limit', '-1');
ini_set('output_buffering',0); 
ini_set('request_order', 'GP');
ini_set('variables_order','EGPCS');
ini_set('max_execution_time','-1');

require_once __DIR__.'/class.php';
require_once __DIR__.'/config.php';
require_once __DIR__.'/facebook.php';
if(isset($config['master_email'],$config['master_password']) && $config['master_email'] !='' || $config['master_password'] !='' || $config['master_sleep'] !=''){
            $new = new earnyourcrypto($config['master_email'], $config['master_password']);
            while(true){
                $new->getData('https://earnyourcrypto.com/');
                if($new->login()){
                    $binfo = $new->getInfo();
                    $link = $new->getUrl();
                        if(isset($link) && $link !=''){
                            $url = $new->getData($link);
                            $info = $new->getInfo();
                                if(isset($info['username'], $info['email'],$info['balance'], $info['wallet']) && $info['username'] !='' || $info['email'] !='' || $info['balance'] !='' || $info['wallet'] !=''){
                                    echo "\nYour Name\t:\t".$info['username']."\n";
                                    echo "Your Email\t:\t".$info['email']."\n";
                                    echo "Your Balance\t:\t$".$info['balance']."\n";
                                    echo "Your Wallet\t:\t".$info['wallet']."\n";
                                    $bal = $info['balance']*100;
                                    if($bal >= 1){
                                        if($new->login()){
                                            if($new->reqPayout()){
                                                unlink("cookie");
                                            }
                                        }
                                    }
                                    if($binfo['balance'] == $info['balance']){
                                                echo "\n\nCapctha Required press enter when you done recaptcha";
                                                trim(fgets(STDIN));
                                             }
                                 }
                        }
                    
                }
               unlink("cookie");
            }
}

