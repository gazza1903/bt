<?php
date_default_timezone_set('Asia/Jakarta');
error_reporting(true);
set_time_limit(0);
ini_set('memory_limit', '-1');
ini_set('output_buffering',0); 
ini_set('request_order', 'GP');
ini_set('variables_order','EGPCS');
ini_set('max_execution_time','-1');

require __DIR__.'/PhpImap/autoload.php';
require __DIR__.'/autoload.php';
require __DIR__.'/config.php';

use CloudflareBypass\RequestMethod\CFCurl;
$mailbox = new PhpImap\Mailbox('{'.$config['host'].'/imap/ssl/novalidate-cert}INBOX', $config['user'], $config['pass'], __DIR__);
while(true){
    $mailsIds = $mailbox->searchMailbox('ALL');
    foreach($mailsIds as $id){
        $mail = $mailbox->getMail($id);
        $link = $mail->textHtml;
        echo "Mail from ".$mail->fromAddress." To ".$mail->toString."\n";
        $r = explode("<a href='https://earnyourcrypto.com/confirm.php?confirm_id=", $link);
        if(isset($r[1]) && $r[1]!=''){
        $s = explode("' target='_blank'>", $r[1]);
            if(isset($s[0]) && $s[0]!=''){
                if(browser('https://earnyourcrypto.com/confirm.php?confirm_id='.$s[0])){
                 $mailbox->deleteMail($id);
                }
            }
        }
        $mailbox->deleteMail($id);
        $mailbox->expungeDeletedMails();
        system("clear");
    }
}

function browser($url){
 $curl = new CFCurl(array('cache' => false, 'max_retries' => 3));
 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, $url);
 curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 $get['exec'] = $curl->exec($ch);
 $get['info'] = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
 curl_close($ch);
 return $get;
}