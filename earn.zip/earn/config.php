<?php

$config['host'] = 'mail.ipkzone.sukaria.net';
$config['user'] = 'cryptozone@ipkzone.sukaria.net';
$config['pass'] = 'Cryptozone123';
$config['mailhost'] = array('ipkzone.sukaria.net','4fileshare.ga','bemine.ml','blankspacehost.ga','trustmail.tk','vemail.ga','xpmail.tk','yonexmail.ml','globalmailist.cf','globalmailist.ga','globalmailist.gq','globalmailist.ml','globalmailist.tk','mailinside.cf','mailinside.ga','mailinside.gq','mailinside.ml','mailinside.tk','mailmoneys.cf','mailmoneys.ga','mailmoneys.gq','mailmoneys.ml','mailmoneys.tk','unomailservice.cf','unomailservice.ga','unomailservice.gq','unomailservice.ml','unomailservice.tk');
  
$config['sleep'] = 200; //detik

// untuk Set wallet masih belom work
$config['wallet'] =''; //wallet xrp
$config['tag'] = ''; //tag wallet

$config['master_email'] = 'a';
$config['master_password'] = '';
$config['master_sleep'] = 200; //detik

//Untuk Laporan Autopost Ke facebook
$config['userfb'] =''; //username atau email facebook
$config['passfb'] =''; //password facebook

/*
sebelum menggunakan auto post ke fb buka dulu fb mengunakan web browser dan kemudian buka link di bawah

https://www.facebook.com/v2.2/dialog/oauth?response_type=token&display=iframe&client_id=174829003346&redirect_uri=https%3A%2F%2Fwww.facebook.com%2Fconnect%2Flogin_success.html&scope=email%2Cpublish_actions%2Cpublish_stream%2Cuser_likes%2Cuser_status%2Cuser_about_me%2Cuser_location%2Cuser_tagged_places%2Cuser_birthday%2Cuser_photos%2Cuser_videos%2Cuser_education_history%2Cuser_posts%2Cuser_website%2Cuser_friends%2Cuser_relationship_details%2Cuser_work_history%2Cuser_games_activity%2Cuser_relationships%2Cuser_hometown%2Cuser_religion_politics%2Cuser_actions.books%2Cuser_actions.music%2Cuser_actions.video%2Cuser_actions.fitness%2Cuser_actions.news%2Cfriends_about_me%2Cfriends_actions.books%2Cfriends_actions.music%2Cfriends_actions.news%2Cfriends_actions.video%2Cfriends_activities%2Cfriends_birthday%2Cfriends_checkins%2Cfriends_education_history%2Cfriends_events%2Cfriends_games_activity%2Cfriends_groups%2Cfriends_hometown%2Cfriends_interests%2Cfriends_likes%2Cfriends_location%2Cfriends_notes%2Cfriends_photo_video_tags%2Cfriends_photos%2Cfriends_questions%2Cfriends_relationship_details%2Cfriends_relationships%2Cfriends_religion_politics%2Cfriends_status%2Cfriends_subscriptions%2Cfriends_videos%2Cfriends_website%2Cfriends_work_history%2Cads_management%2Cpages_messaging%2Cread_page_mailboxes%2Cads_read%2Cpages_messaging_phone_number%2Crsvp_event%2Cmanage_pages%2Cpages_messaging_subscriptions%2Cuser_events%2Cpages_manage_cta%2Cpages_show_list%2Cuser_managed_groups%2Cpages_manage_instant_articles%2Cpublish_pages%2Cinstagram_basic%2Cinstagram_manage_insights%2Cread_custom_friendlists%2Cinstagram_manage_comments%2Cread_audience_network_insights%2Cread_insights%2Cread_stream&status=granted&method=GET

*/