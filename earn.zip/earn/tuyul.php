<?php
date_default_timezone_set('Asia/Jakarta');
error_reporting(true);
set_time_limit(800);
ini_set('memory_limit', '-1');
ini_set('output_buffering',0); 
ini_set('request_order', 'GP');
ini_set('variables_order','EGPCS');
ini_set('max_execution_time','-1');

require __DIR__.'/class.php';
require __DIR__.'/facebook.php';
require __DIR__.'/config.php';

while(true){
    $files = file_get_contents(__DIR__.'/accounts_list.txt');
    $files = str_replace("\r\n", "\n", $files);
    $file = explode("\n", $files);
    foreach($file as $data){
        $login =explode(':', $data);
        $mail = $login[0];
        $pass = $login[1];
        if(isset($mail,$pass) && $mail !='' || $pass!=''){
             $new = new earnyourcrypto($mail, $pass);
                    $new->getData('https://earnyourcrypto.com/');
                        if($new->login()){
                            $new->postData('https://earnyourcrypto.com/captcha','captcha_type=2&coinhive-captcha-token=Z4poQNoX8kLeGKLG6WNaRYt5yGY9tiNx&click_captcha_coinhive=I%27m+not+a+robot%21&g-recaptcha-response=');
                            $binfo = $new->getInfo();
                            $link = $new->getUrl();
                                if(isset($link) && $link !=''){
                                    $new->getData($link);
                                    $info = $new->getInfo();
                                        if(isset($info['username'], $info['email'],$info['balance'], $info['wallet']) && $info['username'] !='' || $info['email'] !='' || $info['balance'] !='' || $info['wallet'] !=''){
                                            echo "\nAll Account ".count($file)."\n";
                                            echo "\nYour Name\t:\t".$info['username']."\n";
                                            echo "Your Email\t:\t".$info['email']."\n";
                                            echo "Your Balance\t:\t$".$info['balance']."\n";
                                            echo "Your Wallet\t:\t".$info['wallet']."\n";
                                            $bal = $info['balance']*100;
                                            if($bal >= 1){
                                                if($new->reqPayout()){
                                                        unlink("cookie");
                                                }
                                            }
                                            if($binfo['balance'] == $info['balance']){
                                                echo "\n\nCapctha Required\n";
                                                $fil = file_get_contents(__DIR__.'/verify_captcha.txt');
                                                if(preg_match("/".$mail.':'.$pass."/i",$fil)){
                                                }else{
                                                    $fi = fopen('verify_captcha.txt', 'a');
                                                          fwrite($fi, $mail.':'.$pass."\n");
                                                          fclose($fi);
                                                }
                                             }
                                         }
                                }

                        }
                        unlink("cookie");
        }
        sleep($config['sleep']);
    }
}
